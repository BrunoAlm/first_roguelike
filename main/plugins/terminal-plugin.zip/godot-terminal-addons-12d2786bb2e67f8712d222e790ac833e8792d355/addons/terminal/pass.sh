#!/bin/bash
echo -n $SUDO_PASS
